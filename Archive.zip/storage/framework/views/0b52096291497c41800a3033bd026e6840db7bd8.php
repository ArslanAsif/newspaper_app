<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Upload News Image <small>Step 2 of 2</small></h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br />

                            <form action="#" class="form-horizontal form-label-left">
                                <div class="image-editor">
                                    <input type="file" class="cropit-image-input">
                                    <div class="cropit-preview"></div>
                                    <div class="image-size-label">
                                        Resize image
                                    </div>
                                    <input type="range" class="cropit-image-zoom-input">
                                    <input type="hidden" name="image-data" class="hidden-image-data" />

                                    <div class="ln_solid"></div>
                                    <div class="">
                                        <div class="pull-right">
                                            <button type="submit" class="btn btn-primary">Skip Image</button>
                                            <button type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>

                            <div id="result">
                                <code>$form.serialize() =</code>
                                <code id="result-data"></code>
                            </div>

                            

                                

                                

                                

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <!-- cropit -->
    <style>
        .cropit-preview {
            background-color: #f8f8f8;
            background-size: cover;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-top: 7px;
            height: 250px;
            width: 250px;
        }

        .cropit-preview-image-container {
            cursor: move;
        }

        .image-size-label {
            margin-top: 10px;
        }

        input {
            display: block;
        }

        button[type="submit"] {
            margin-top: 10px;
        }

        #result {
            margin-top: 10px;
            width: 900px;
        }

        #result-data {
            display: block;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            word-wrap: break-word;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- cropit -->
    <script src="<?php echo e(url('vendors/cropit/dist/jquery.cropit.js')); ?>"></script>

    <script>
        $(function() {
            $('.image-editor').cropit();

            $('#image-submit').click(function() {
                // Move cropped image data to hidden input
                var imageData = $('.image-editor').cropit('export');
                $('.hidden-image-data').val(imageData);

                // Print HTTP request params
                var formValue = $(this).serialize();
                $('#result-data').text(formValue);

                // Prevent the form from actually submitting
                return false;
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>