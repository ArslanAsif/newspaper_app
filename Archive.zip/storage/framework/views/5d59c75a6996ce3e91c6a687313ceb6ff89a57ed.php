<?php $__env->startSection('content'); ?>
    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
            <div class="clearfix"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Add Category <small></small></h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br />
                            <?php if($check=="add"): ?>
                            <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post" action="<?php echo e(url('admin/news/category/add')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category">Category Name <span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="text" id="category" name="category" required="required" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="parent-category" class="control-label col-md-3 col-sm-3 col-xs-12">Parent Category (if any)</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="form-control" name="parent-category">
                                            <option></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="priority">Priority <span class="required">*</span>
                                    </label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="number" id="priority" name="priority" required="required" class="form-control col-md-7 col-xs-12">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3 col-sm-offset-3">
                                        <div class="">
                                            <label>
                                                <input name="active" type="checkbox" class="js-switch" checked/> Active
                                            </label>
                                        </div>
                                        <div class="">
                                            <label>
                                                <input name="homepage" type="checkbox" class="js-switch"/> Show on Homepage
                                            </label>
                                        </div>
                                        <div class="">
                                            <label>
                                                <input name="latest" type="checkbox" class="js-switch"/> Show in Latest
                                            </label>
                                        </div>
                                    </div>
                                </div>

                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                        <button type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>

                            </form>
                            <?php elseif($check=="update"): ?>
                                <?php $__currentLoopData = $cateData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cateData): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="post" action="<?php echo e(url('admin/news/category/edit/'.$cateData->id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="category">Category Name <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input type="text" id="category" value="<?php echo e($cateData->name); ?>" name="category" required="required" class="form-control col-md-7 col-xs-12">
                                            <input type="hidden" id="id" value="<?php echo e($cateData->id); ?>" name="id" required="required" class="form-control col-md-7 col-xs-12">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="parent-category" class="control-label col-md-3 col-sm-3 col-xs-12">Parent Category (if any)</label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <select class="form-control" name="parent-category">
                                                <option></option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <?php if($cateData->category_id==$category->id): ?>
                                                    <option selected value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> </option>
                                                    <?php else: ?>
                                                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?> </option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="priority">Priority <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input type="number" value="<?php echo e($cateData->priority); ?>" id="priority" name="priority" required="required" class="form-control col-md-7 col-xs-12">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3 col-sm-offset-3">
                                            <div class="">
                                                <label>
                                                    <?php if($cateData->active==1): ?>
                                                    <input name="active" type="checkbox" class="js-switch" checked/> Active
                                                    <?php else: ?>
                                                     <input name="active" type="checkbox" class="js-switch" />In Active
                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                            <div class="">
                                                <label>
                                                    <?php if($cateData->homepage==1): ?>
                                                    <input name="homepage" type="checkbox" checked class="js-switch"/> Show on Homepage.
                                                    <?php else: ?>
                                                    <input name="homepage" type="checkbox" class="js-switch"/> Show on Homepage.
                                                    <?php endif; ?>

                                                </label>
                                            </div>
                                            <div class="">
                                                <label>
                                                    <?php if($cateData->latest==1): ?>
                                                    <input name="latest" type="checkbox" checked class="js-switch"/> Show in Latest
                                                    <?php else: ?>
                                                      <input name="latest" type="checkbox"  class="js-switch"/> Show in Latest
                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="ln_solid"></div>
                                    <div class="form-group">
                                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                            <button type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                </form>

                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Switchery -->
    <link href="<?php echo e(url('vendors/switchery/dist/switchery.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Switchery -->
    <script src="<?php echo e(url('vendors/switchery/dist/switchery.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>