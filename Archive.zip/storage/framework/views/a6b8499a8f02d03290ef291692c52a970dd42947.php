<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="clearfix"></div>

            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>User Submissions <small></small></h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <p class="text-muted font-13 m-b-30">
                                User submitted news, articles and colums can be reviewed here for publishing. Once Published it will be moved to news tab.
                            </p>
                            <table id="datatable" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Category</th>
                                    <th>Author</th>
                                    <th>Submitted On</th>
                                    <th></th>
                                </tr>
                                </thead>


                                <tbody>

                                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $this_news): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><?php echo e($this_news->title); ?></td>
                                    <td><?php echo e($this_news->type); ?></td>
                                    <td><?php echo e($this_news->category->name); ?></td>
                                    <td><?php echo e($this_news->user->name); ?></td>
                                    <td><?php echo e($this_news->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/admin/news/edit/'.$this_news->id)); ?>" class="btn btn-default"><span class="fa fa-pencil-square-o"></span></a>
                                        <a href="<?php echo e(url('/admin/news/delete/'.$this_news->id)); ?>" class="btn btn-danger"><span class="fa fa-trash-o"></span></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.includes.datatable_links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.layouts.admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>